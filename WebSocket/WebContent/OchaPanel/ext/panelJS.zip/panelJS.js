		var DSR_SEQ = "";		
		var dsr;
		var carmove;
		var ctlproc;
		var x;
		function init(){
			var ws = new WSocket("127.0.0.1", "9292", "disaster");
			ws.connect();
			
			dsr = new DSRController();
			carmove = new CarMoveController();
			ctlproc = new CTLProcController();			
			
			
			document.getElementById("reconnect").addEventListener("click",ws.connect());
		}
		// 재난 객체
		var DSR = (function() {
			function DSR(o){
				this.o = o;
				this.seq = o.TABLEINFO.KEYS.DSR_SEQ;								
			}
			DSR.prototype.setXXX = function(){
				
			}
			return DSR;
		})();
		// 재난 컨트롤러
		var DSRController = (function() {
			function DSRController(){
				this.list = new Array();				
			}
			DSRController.prototype.addDSR = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ ){
						return;
					}
				}
				this.list.push(d);
				return;
			};
			DSRController.prototype.replaceDSR = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ ){
						this.list.splice(i,1,d);
						return;
					}
				}
				return;
			};
			DSRController.prototype.deleteDSR = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ ){
						this.list.slice(0,i).concat(this.list.slice(i+1,this.list.length));
						return;
					}
				}
				return;
			};
			DSRController.prototype.findDSR = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ){
						return i;
					}
				}
				return -1;
			};
			DSRController.prototype.listDSR = function(d){
				this.gridList = new Array();
				for(var i = 0 ; this.list.length ; i++){
					this.gridList.push(d.RECORDINFO);
				}	
				return gridList;
			};
			return DSRController;
		})();
		
		// 차량 객체
		var CarMove = (function() {
			function CarMove(o){
				this.o = o;
				this.seq = o.TABLEINFO.KEYS.DSR_SEQ;							
			}
			CarMove.prototype.setXXX = function(){
				
			};
			return CarMove;
		})();
		// 차량 컨트롤러
		var CarMoveController = (function() {
			function CarMoveController(){
				this.list = new Array();			
				this.gridList = new Array();
			}
			CarMoveController.prototype.setXXX = function(){
				
			};
			CarMoveController.prototype.addCarMove = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ && this.list[i].TABLEINFO.KEYS.CAR_ID == d.TABLEINFO.KEYS.CAR_ID && this.list[i].TABLEINFO.KEYS.DSP_ORD == d.TABLEINFO.KEYS.DSP_ORD){
						return;
					}
				}
				this.list.push(d);
				return;
			};
			CarMoveController.prototype.replaceCarMove = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ && this.list[i].TABLEINFO.KEYS.CAR_ID == d.TABLEINFO.KEYS.CAR_ID && this.list[i].TABLEINFO.KEYS.DSP_ORD == d.TABLEINFO.KEYS.DSP_ORD){
						this.list.splice(i,1,d);
						return;
					}
				}
				return;
			};
			CarMoveController.prototype.deleteCarMove = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ && this.list[i].TABLEINFO.KEYS.CAR_ID == d.TABLEINFO.KEYS.CAR_ID && this.list[i].TABLEINFO.KEYS.DSP_ORD == d.TABLEINFO.KEYS.DSP_ORD){
						this.list.slice(0,i).concat(this.list.slice(i+1,this.list.length));
						return;
					}
				}
				return;
			};
			CarMoveController.prototype.findCarMove = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ && this.list[i].TABLEINFO.KEYS.CAR_ID == d.TABLEINFO.KEYS.CAR_ID && this.list[i].TABLEINFO.KEYS.DSP_ORD == d.TABLEINFO.KEYS.DSP_ORD){
						return i;
					}
				}
				return -1;
			};
			CarMoveController.prototype.listCarMove = function(d){
				this.gridList = new Array();
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ ){
						this.gridList.push(d.RECORDINFO);
					}
				}	
				return gridList;			
			};
			return CarMoveController;
		})();
		
		// 관제 객체
		var CTLProc = (function() {
			function CTLProc(o){
				this.o = o;
				this.seq = o.TABLEINFO.KEYS.DSR_SEQ;		
			}
			CTLProc.prototype.setXXX = function(){
				
			};
			return CTLProc;
		})();
		// 관제 컨트롤러
		var CTLProcController = (function() {
			function CTLProcController(){
				this.list = new Array();	
				this.gridList = new Array();
			}
			CTLProcController.prototype.setXXX = function(){
				
			};
			CTLProcController.prototype.addCTLProc = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ && this.list[i].TABLEINFO.KEYS.CTL_SEQ == d.TABLEINFO.KEYS.CTL_SEQ){
						return;
					}
				}
				this.list.push(d);
				return;
			};
			CTLProcController.prototype.replaceCTLProc = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ && this.list[i].TABLEINFO.KEYS.CTL_SEQ == d.TABLEINFO.KEYS.CTL_SEQ){
						this.list.splice(i,1,d);
						return;
					}
				}
				return;
			};
			CTLProcController.prototype.deleteCTLProc = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ && this.list[i].TABLEINFO.KEYS.CTL_SEQ == d.TABLEINFO.KEYS.CTL_SEQ){
						this.list.slice(0,i).concat(this.list.slice(i+1,this.list.length));
						return;
					}
				}
				return;
			};
			CTLProcController.prototype.deleteAllCTLProc = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ && this.list[i].TABLEINFO.KEYS.CTL_SEQ == d.TABLEINFO.KEYS.CTL_SEQ){
						this.list.slice(0,i).concat(this.list.slice(i+1,this.list.length));
					}
				}
				return;
			};
			CTLProcController.prototype.findCTLProc = function(d){
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ && this.list[i].TABLEINFO.KEYS.CTL_SEQ == d.TABLEINFO.KEYS.CTL_SEQ){
						return i;
					}
				}
				return -1;
			};
			CTLProcController.prototype.listCTLProc = function(d){
				this.gridList = new Array();
				for(var i = 0 ; this.list.length ; i++){
					if(this.list[i].TABLEINFO.KEYS.DSR_SEQ == d.TABLEINFO.KEYS.DSR_SEQ ){
						this.gridList.push(d.RECORDINFO);
					}
				}		
				return gridList;		
			};
			return CTLProcController;
		})();
		
		// 웹소켓 객체(RECV)
		var WSocket = (function() {
			function WSocket(ip, port, param) {
				var ws = this;
				this.ip = ip;
				this.port = port;
				this.param = param;
				this.status = "DISCONNECTED";
			};
			
			WSocket.prototype.connect = function() {
				var ws = this;
				this.wSocket = new WebSocket("ws://"+this.getIP()+":"+this.getPort()+"/"+this.param);	
				this.wSocket.onopen = function (e){
					console.log("Connected.");
					this.status = "CONNECTED";
				}
				
				this.wSocket.onmessage = function (e) {
					//socketReceived
					var d = JSON.parse(e.data);
					console.log(d);
					x = d;
					if(!d.hasOwnProperty("TABLEINFO")) return;
					if(d.TABLEINFO.TABLE_NM == "ERSS.CM_DSR_ACT"){ // CM_DSR
						if(d.METHOD == "GET"){
							// X
						}else if(d.METHOD == "POST"){
							dsr.addDSR(d);
							alignGrid("DSRPanel",dsr.listDSR(d));
						}else if(d.METHOD == "PUT"){
							dsr.replaceDSR(d);			
							alignGrid("DSRInfoPanel",dsr.listDSR(d));				
						}else if(d.METHOD == "DELETE"){
							dsr.deleteDSR(d);	
							alignGrid("DSRInfoPanel",dsr.listDSR(d));	
							// 재난 삭제, 관제/차량삭제, 화면초기화
						}
					}else if(d.TABLEINFO.TABLE_NM == "ERSS.ERSS.CT_DSPCARMOVE_ACT"){ // CT_DSPCARMOVE
						if(d.METHOD == "GET"){
							// X
						}else if(d.METHOD == "POST"){
							carmove.addCarMove(d);								
						}else if(d.METHOD == "PUT"){
							carmove.replaceCarMove(d);			
						}else if(d.METHOD == "DELETE"){
							// X
						}						
					}else if(d.TABLEINFO.TABLE_NM == "CT_CTLPROC_ACT"){ // CT_CTLPROC
						if(d.METHOD == "GET"){
							// X
						}else if(d.METHOD == "POST"){
							ctlproc.addCTLProc(d);									
						}else if(d.METHOD == "PUT"){
							// X ctlproc.replaceCTLProcController(d);
						}else if(d.METHOD == "DELETE"){
							// X
						}						
					}					
				}
				
				this.wSocket.onclose = function (e) {
					console.log("Socket closed.");
					ws.status = "DISCONNECTED";
					setTimeout(3000,ws.connect());
				}
			}
			
			WSocket.prototype.getIP = function() {
				return this.ip;
			};
			
			WSocket.prototype.getPort = function() {
				return this.port;
			};
			
			WSocket.prototype.send = function(str) {
				this.wSocket.send(str);
				return str;
			};
			
			return WSocket;
		})();
		
		function changeDSR(DSR){
			D.TABLEINFO.DSR_SEQ = DSR;
			alignGrid("DSRPanel",dsr.listDSR());
			alignGrid("CTLProcPanel",ctlproc.listCTLProc(D));
			alignGrid("CarMovePanel",carmove.listCarMove(D));			
		}
		function alignGrid(id,data){
			var obj = document.getElementById(id);
			if(id == "DSRInfoPanel"){
				var str = "";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>DSR_SEQ</div>";
				str += "<div class='col-sm-4'>"+data.REG_DTIME+"</div>";
				str += "</div>";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>ADDR_NAME</div>";
				str += "<div class='col-sm-4'>"+data.ADDR_NAME+"</div>";
				str += "</div>";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>DSR_KND_NM</div>";
				str += "<div class='col-sm-4'>"+data.DSR_KND_NM+"</div>";
				str += "</div>";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>DSR_CLS_NM</div>";
				str += "<div class='col-sm-4'>"+data.DSR_CLS_NM+"</div>";
				str += "</div>";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>JURIS_WARD_ID</div>";
				str += "<div class='col-sm-4'>"+data.JURIS_WARD_ID+"</div>";
				str += "</div>";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>TTY_ID</div>";
				str += "<div class='col-sm-4'>"+data.TTY_ID+"</div>";
				str += "</div>";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>STATION_NM</div>";
				str += "<div class='col-sm-4'>"+data.STATION_NM+"</div>";
				str += "</div>";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>GIS_X</div>";
				str += "<div class='col-sm-4'>"+data.GIS_X+"</div>";
				str += "</div>";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>GIS_Y</div>";
				str += "<div class='col-sm-4'>"+data.GIS_Y+"</div>";
				str += "</div>";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>PSLTE_TALK_GRP</div>";
				str += "<div class='col-sm-4'>"+data.PSLTE_TALK_GRP+"</div>";	
				str += "</div>";
				obj.innerHTML = str;
			}else if(id == "DSRPanel"){
				var str = "";
				str += "<div class='row'>";
				str += "<div class='col-sm-2'>DSR_SEQ</div>";
				str += "<div class='col-sm-2'>20160308174227</div>";
				str += "<div class='col-sm-2'>ADDR_NAME</div>";
				str += "<div class='col-sm-2'>DSR_KND_NM</div>";
				str += "<div class='col-sm-2'>DSR_CLS_NM</div>";
				str += "<div class='col-sm-2'>JURIS_WARD_ID</div>";
				str += "<div class='col-sm-2'>TTY_ID</div>";
				str += "<div class='col-sm-2'>STATION_NM</div>";
				str += "<div class='col-sm-2'>GIS_X</div>";
				str += "<div class='col-sm-2'>GIS_Y</div>";
				str += "<div class='col-sm-2'>PSLTE_TALK_GRP</div>";
				str += "</div>";
				for(var i = 0 ; i < dsr.list.length ; i++){
					str += "<div onclick='changeDSR("+data[i].DSR_SEQ+")'>";
					str += "<div class='col-sm-2'>"+data[i].DSR_SEQ+"</div>";
					str += "<div class='col-sm-2'>"+data[i].REG_DTIME+"</div>";
					str += "<div class='col-sm-2'>"+data[i].ADDR_NAME+"</div>";
					str += "<div class='col-sm-2'>"+data[i].DSR_KND_NM+"</div>";
					str += "<div class='col-sm-2'>"+data[i].DSR_CLS_NM+"</div>";
					str += "<div class='col-sm-2'>"+data[i].JURIS_WARD_ID+"</div>";
					str += "<div class='col-sm-2'>"+data[i].TTY_ID+"</div>";
					str += "<div class='col-sm-2'>"+data[i].STATION_NM+"</div>";
					str += "<div class='col-sm-2'>"+data[i].GIS_X+"</div>";
					str += "<div class='col-sm-2'>"+data[i].GIS_Y+"</div>";
					str += "<div class='col-sm-2'>"+data[i].PSLTE_TALK_GRP+"</div>";		
					str += "</div>";
				}
				obj.innerHTML = str;				
			}else if(id == "CarMovePanel"){
				var str = "";
				str += "<div class='row'>";
				str += "<div class='col-sm-2'>DSP_ORD</div>";
				str += "<div class='col-sm-2'>WARD_NAME</div>";
				str += "<div class='col-sm-2'>RADIO_CALLSIGN</div>";
				str += "<div class='col-sm-2'>CAR_CD</div>";
				str += "<div class='col-sm-2'>DSP_DTIME</div>";
				str += "<div class='col-sm-2'>DSP_ARR_DTIME</div>";
				str += "<div class='col-sm-2'>DSP_HOS_DTIME</div>";
				str += "<div class='col-sm-2'>DSP_RTN_DTIME</div>";
				str += "<div class='col-sm-2'>DSP_END_DTIME</div>";
				str += "</div>";
				for(var i = 0 ; i < carmove.list.length ; i++){
					str += "<div>";
					str += "<div class='col-sm-2'>"+data[i].DSP_ORD+"</div>";
					str += "<div class='col-sm-2'>"+data[i].WARD_NAME+"</div>";
					str += "<div class='col-sm-2'>"+data[i].RADIO_CALLSIGN+"</div>";
					str += "<div class='col-sm-2'>"+data[i].CAR_CD+"</div>";
					str += "<div class='col-sm-2'>"+data[i].DSP_DTIME+"</div>";	
					str += "<div class='col-sm-2'>"+data[i].DSP_ARR_DTIME+"</div>";
					str += "<div class='col-sm-2'>"+data[i].DSP_HOS_DTIME+"</div>";	
					str += "<div class='col-sm-2'>"+data[i].DSP_RTN_DTIME+"</div>";
					str += "<div class='col-sm-2'>"+data[i].DSP_END_DTIME+"</div>";	
					str += "</div>";
				}
				obj.innerHTML = str;				
			}else if(id == "CTLProcPanel"){
				var str = "";
				str += "<div class='row'>";
				str += "<div class='col-sm-4'>CTL_SEQ</div>";
				str += "<div class='col-sm-4'>CD_NAME</div>";
				str += "<div class='col-sm-4'>CTL_DESC</div>";
				str += "<div class='col-sm-4'>USER_NAME</div>";
				str += "<div class='col-sm-4'>CTL_PROC_DTIME</div>";
				str += "</div>";
				for(var i = 0 ; i < ctlproc.list.length ; i++){
					str += "<div>";
					str += "<div class='col-sm-4'>"+data[i].CTL_SEQ+"</div>";
					str += "<div class='col-sm-4'>"+data[i].CD_NAME+"</div>";
					str += "<div class='col-sm-4'>"+data[i].CTL_DESC+"</div>";
					str += "<div class='col-sm-4'>"+data[i].USER_NAME+"</div>";
					str += "<div class='col-sm-4'>"+data[i].CTL_PROC_DTIME+"</div>";	
					str += "</div>";
				}
				obj.innerHTML = str;							
			}
		}